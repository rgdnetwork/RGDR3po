# RGDR3po
Repositorio de Addons de Kodi creado por Rgdnetwork, Rgdnetwork no son los propietarios, ni los reponsables de los addons ni de su contenido.
